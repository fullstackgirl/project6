export class LoginUser {
    public username: string;
    public password: string;
}
