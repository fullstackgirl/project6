export class Note {
    public title: string;
    public text: string;
}
